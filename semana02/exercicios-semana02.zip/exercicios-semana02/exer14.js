// 14 -Construa um objeto chamado myUser que possuias propriedades: 
// name, age e email, coloque valores de sua escolha nessas propriedades 
// e imprima o objeto no console.


let myUser = {
    proriedades: [
        {name: "Juca"},
        {age: "25"},
        {email: "juca@gmail.com"}
    ]
}

console.log(myUser.proriedades)