//04 - Imprima no console a multiplicação de 42 por-3.14.

let x = 42
let y = -3.14

console.log(x*y)
