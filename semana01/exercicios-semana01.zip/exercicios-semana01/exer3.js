// 03 - Faça um programa que armazene em duas variáveis distintas, 
//um nome e um sobrenome, e imprima no console o nome completo.

let name = "Marianne"
let fullName = "Melo"

console.log(name + " " + fullName)

