//05 - Faça um programa que armazene dois valores nas variáveis valor1 e valor2. 
//Efetue a soma de valor1 e valor2 atribuindo o seu resultado na variável resultado. 
//Imprima no console o valor armazenado em resultado.

let valor1 = 10
let valor2 = 5
let soma = (valor1 + valor2)
console.log(soma)