// 11 - Tendo como informação os três lados de um triângulo 
// faça um programa que imprima na tela se ele é EQUILÁTERO, ISÓSCELES ou ESCALENO.
// OBS: 
// Triângulo Equilátero → Possui os 3 lados iguais; 
// Triângulo Isósceles → Possui 2 lados iguais; 
// Triângulo Escaleno → Possui 3 lados diferentes.

let ladoOne = 4
let ladoTwo = 4
let ladoThree = 4

if (ladoOne == ladoTwo == ladoThree){
    console.log("O triângulo é Equilátero")
} else {
    console.log("O triângulo é Escaleno")
} 

