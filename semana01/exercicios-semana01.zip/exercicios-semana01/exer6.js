// 06 - Uma imobiliária paga às pessoas corretoras de imóveis um salário 
// ﬁxo por mês e uma comissão de acordo com o valor de vendas realizado por elas. 
// Faça um programa que calcule e imprima no console o valor total recebido pela pessoa corretora de imóveis no mês.

let salarioFixo = 2000
let valorTotalVendido = 30000
let comissão = 0.01

console.log(salarioFixo + (valorTotalVendido * comissão))