// 17 - Faça um programa que receberá a hora inicial e a hora ﬁnal de um jogo.
// A seguir calcule a duração do jogo, sabendo que o mesmo pode começar em um dia 
// e terminar em outro, tendo uma duração máxima de 24 horas. 



function jogo (horaInicio, horaFinal) {
    let duracao = (horaFinal-horaInicio)
      console.log("O jogo começará as " + horaInicio + "h e terminará as " + horaFinal + "h. E terá a duração de " + duracao + "h.")
}
jogo (9, 20)