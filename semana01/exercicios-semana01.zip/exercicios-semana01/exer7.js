// 07 - Tendo como informação dois valores, valor1 e valor2, 
// faça um programa que imprima os dois valores no console. 
// Após imprimir,troque a informação de valor1 pela informação do valor2 e imprima no console novamente.

let valor1 = 3
let valor2 = 12

console.log(valor1 + " " + valor2)

let valor3
valor3 = valor1
valor1 = valor2
valor2 = valor3


console.log(valor1 + " " + valor2)

