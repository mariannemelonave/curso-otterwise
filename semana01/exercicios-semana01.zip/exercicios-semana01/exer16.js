// 16 - Escreva um programa que receba como entrada dois valores. 
// Após, o programa deve mostrar uma mensagem “São Múltiplos” ou “Não são Múltiplos”, 
// indicando se os valores recebidos como entrada são múltiplos entre si.


let numberOne = 10
let numberTwo = 3

if (numberOne%numberTwo === 0 ){
    console.log("São múltiplos")
} else {
    console.log("Não são múltiplos")
}

