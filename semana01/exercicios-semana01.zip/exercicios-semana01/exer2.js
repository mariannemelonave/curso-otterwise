// Crie um programa que lê dois valores, x e y, e diz se algum desses valores épositivo.

let x = -1
let y= -10

/*
if (x > 0){
    console.log("Um dos valores é positivo")
} else if (y > 0){
    console.log("Um dos valores é positivo")
} else {
    console.log("Nenhum dos valores é positivo")
}
*/

// 02 - Atribua a uma constante a soma das strings "Otter" e "wise" e imprima no console seu valor.

let name = "Otter"
let fullName = "Wise"

console.log(name + fullName)