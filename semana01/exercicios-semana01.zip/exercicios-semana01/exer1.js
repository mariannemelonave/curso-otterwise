//Exercício 1

/*let firstName = "Marianne"
let lastName = "Melo"
let day = 12 
let month = "0" + 6
let year = 1994

console.log("Nome Completo: " + firstName + " " + lastName)
console.log("Data de nascimento: " + day + "/" + month + "/" + year)
*/

//01 - Faça um programa que imprima no console uma frase que contenha seu nome e sua formação

let name = "Marianne"
let formacao = "Design de Interiores"

console.log("Meu nome é " + name + " e sou formada em " + formacao)
