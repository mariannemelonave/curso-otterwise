// 13 - Tendo como informação um número, faça um programa que imprime no console se esse número é par ou ímpar.

let number = 10

if(number%2 == 0){
	console.log("Este número é par");
}else{
	console.log("Este número é ímpar");
}

