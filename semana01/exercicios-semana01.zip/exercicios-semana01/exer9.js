// 09 - Tendo como informações um nome e uma idade, 
// faça um programa que imprima no console se a pessoa é maior ou menor de idade.

let name = "Júlia"
let idade = "34"

if (idade > 18){
    console.log(name + " é maior de idade")
} else {
    console.log(name + " é menor de idade")
}
