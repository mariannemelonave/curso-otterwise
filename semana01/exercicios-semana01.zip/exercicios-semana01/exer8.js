// 08 - Calcule a média de consumo de combustível utilizada em uma viagem e o tempo 
// levado durante a viagem. Você deve imprimir no console esses dois valores:
// Os valores de entrada serão: 
// Distância percorrida na viagem em km; 
// Velocidade do automóvel em km/h; 
// Quantidade de combustível gasto em litros

let distancia = 240
let velocidade = 80
let combustivel = 20

let tempo = distancia / velocidade
let media = distancia / combustivel

console.log("O tempo para a viagem: " + tempo + "h")
console.log("A media de consumo: " + media + " litros")



