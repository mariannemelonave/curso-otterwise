// Dado um array de nomes, faça umprograma que imprima na tela todos os nomes (na mesma linha).

let names = ['Angela', 'Rosa', 'Ticiana', 'Carla', 'Renata']
console.log(names.join(", "))

