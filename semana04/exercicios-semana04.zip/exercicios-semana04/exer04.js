// Crie um algoritmo que tem comoentrada um array de notas, e imprime no console a média aritmética dessas notas.

const notes = [6, 8, 7]

const sum = notes.reduce((acc, num) => { 

soma = acc[num]
return acc + num
})

const mediaNotes = sum/notes.length

//console.log(sum)
console.log(mediaNotes)


